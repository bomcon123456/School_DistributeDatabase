ALTER PROCEDURE integrity_NCC_delete @maNCC char(10)
AS
BEGIN
	DECLARE @locate char(255);
	DECLARE @temp int;
	-- Check key exists.
	IF (SELECT COUNT(a.maNCC)
	FROM SANXUAT as a WHERE a.maNCC = @maNCC) > 0
		THROW 51000, 'There is an existing entity with this primary key. Cant delete.', 1;

	IF (SELECT COUNT(a.maNCC)
	FROM SITE1.QLHH.dbo.NHACUNGCAP as a WHERE a.maNCC = @maNCC) > 0
	BEGIN
		SELECT *
		FROM SITE1.QLHH.dbo.NHACUNGCAP
		WITH (TABLOCK, HOLDLOCK)
		-- delete
		DELETE FROM SITE1.QLHH.[dbo].[NHACUNGCAP]
		WHERE maNCC = @maNCC
		RETURN
	END

	IF (SELECT COUNT(a.maNCC)
	FROM SITE2.QLHH.dbo.NHACUNGCAP as a WHERE a.maNCC = @maNCC) > 0
	BEGIN
		-- lock table
		SET @temp = (SELECT *
					FROM SITE2.QLHH.dbo.NHACUNGCAP
					WITH (TABLOCK, HOLDLOCK))
		-- delete
		DELETE FROM SITE2.QLHH.dbo.NHACUNGCAP
		WHERE maNCC = @maNCC
		RETURN
	END

	IF (SELECT COUNT(a.maNCC)
	FROM SITE3.QLHH.dbo.NHACUNGCAP as a WHERE a.maNCC = @maNCC) > 0
	BEGIN
		-- lock table
		SET @temp = (SELECT *
		FROM SITE3.QLHH.dbo.NHACUNGCAP
		WITH (TABLOCK, HOLDLOCK))
		-- delete
		DELETE FROM SITE3.QLHH.[dbo].[NHACUNGCAP]
		WHERE maNCC = @maNCC
		RETURN
	END
END


DROP PROCEDURE integrity_NCC_delete

exec integrity_NCC_delete '123'