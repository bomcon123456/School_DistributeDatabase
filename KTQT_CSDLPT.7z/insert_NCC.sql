USE [QLHH]
GO

SET XACT_ABORT ON
INSERT INTO NHACUNGCAP
           ([maNCC]
           ,[tenNCC]
           ,[Khuvuc])
     VALUES
           ('21'
           ,'TEST21'
           ,'Hanoi')
GO


SELECT * FROM SITE1.QLHH.dbo.NHACUNGCAP

BEGIN TRANSACTION
SET XACT_ABORT ON
INSERT INTO SITE1.QLHH.dbo.NHACUNGCAP VALUES
           ('123'
           ,'TEST1'
           ,'Hanoi')
COMMIT TRAN	