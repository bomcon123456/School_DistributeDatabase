ALTER FUNCTION View_Products
(@tenNCC char(255))
RETURNS @result TABLE (
		maSP NCHAR(10),
		tenSP CHAR(255),
		Soluong INT
		)
AS
BEGIN
	DECLARE @maNCC nchar(10);
	DECLARE @sp_sl table(maSP NCHAR(10), Soluong INT)
	DECLARE @site_1_sp table(maSP NCHAR(10), tenSP CHAR(255))
	-- Find maNCC
	IF (SELECT COUNT(a.maNCC)
	FROM SITE1.QLHH.dbo.NHACUNGCAP as a WHERE a.tenNCC = @tenNCC) > 0
	BEGIN
		SET @maNCC = (SELECT TOP 1 maNCC FROM SITE1.QLHH.dbo.NHACUNGCAP as a WHERE a.tenNCC = @tenNCC)
	END
	ELSE
	BEGIN
		IF (SELECT COUNT(a.maNCC)
		FROM QLHH.dbo.NHACUNGCAP as a WHERE a.tenNCC = @tenNCC) > 0
		BEGIN
			SET @maNCC = (SELECT TOP 1 maNCC FROM QLHH.dbo.NHACUNGCAP as a WHERE a.tenNCC = @tenNCC)
		END
		ELSE
		BEGIN
			IF (SELECT COUNT(a.maNCC)
			FROM SITE3.QLHH.dbo.NHACUNGCAP as a WHERE a.tenNCC = @tenNCC) > 0
			BEGIN
				SET @maNCC = (SELECT TOP 1 maNCC FROM SITE3.QLHH.dbo.NHACUNGCAP as a WHERE a.tenNCC = @tenNCC)
			END
			ELSE
				RETURN;
		END
	END
	-- Get maSP, Soluong
	INSERT INTO @sp_sl
	SELECT a.maSP, a.Soluong
	FROM QLHH.dbo.SANXUAT as a
	WHERE a.maNCC = @maNCC

	-- GET temp table for SANPHAM
	INSERT INTO @site_1_sp
	SELECT a.maSP, a.tenSP
	FROM SITE1.QLHH.dbo.SANPHAM as a

	-- SET result
	INSERT INTO @result
	SELECT a.maSP, a.tenSP, b.Soluong
	FROM @site_1_sp as a INNER JOIN @sp_sl as b
	ON a.maSP = b.maSP
	RETURN;

END

SELECT * FROM View_Products('TEST2')