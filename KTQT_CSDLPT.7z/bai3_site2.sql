USE [QLHH]
GO

INSERT INTO [NHACUNGCAP]
           ([maNCC]
           ,[tenNCC]
           ,[Khuvuc])
     VALUES
           ('99'
           ,'Sup'
           ,'Others')
GO


