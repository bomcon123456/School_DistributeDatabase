﻿-- Câu 2: Xây dựng thủ tục

-- Chèn dữ liệu vào bảng SANPHAM
CREATE PROCEDURE insert_SP
@maSP nchar(10),
@tenSP char(255),
@trongluong float,
@kho char(255)
AS 
BEGIN
	IF (SELECT @@SERVERNAME) = 'PC3206'
		BEGIN
			INSERT INTO SANPHAM VALUES(@maSP, @tenSP, @kho)
			INSERT INTO SITE2.QLHH.dbo.SANPHAM VALUES(@maSP, @trongluong)
		END
	ELSE
	BEGIN
			IF (SELECT @@SERVERNAME) = 'PC3204'
				BEGIN
					INSERT INTO SANPHAM VALUES(@maSP, @tenSP, @kho)
					INSERT INTO SITE2.QLHH.dbo.SANPHAM VALUES(@maSP, @trongluong)
				END
			ELSE
				BEGIN
					IF (SELECT @@SERVERNAME) = 'PC3202'
					BEGIN
						INSERT INTO SANPHAM VALUES(@maSP, @tenSP, @kho)
						INSERT INTO SITE2.QLHH.dbo.SANPHAM VALUES(@maSP, @trongluong)
					END
				END
	END
END

exec insert_SP
@maSP ='300', 
@tenSP ='SP300', 
@trongluong ='3000',
@kho = 'Hanoi'

DROP PROCEDURE insert_SP




-- INSERT table SANXUAT
CREATE PROCEDURE insert_SANXUAT
@maNCC nchar(10),
@maSP char(255),
@Soluong int

AS
BEGIN
	DECLARE @count_ncc_site1 int;
	DECLARE @count_ncc_site2 int;
	DECLARE @count_ncc_site3 int;
	-- Check maNCC
	SET @count_ncc_site1 = (SELECT COUNT(a.maNCC)
				FROM NHACUNGCAP as a WHERE a.maNCC = @maNCC)
	IF @count_ncc_site1 <= 0
		BEGIN
			SET @count_ncc_site2 = (SELECT COUNT(a.maNCC)
					FROM SITE2.QLHH.dbo.NHACUNGCAP as a WHERE a.maNCC = @maNCC)
			IF @count_ncc_site2 <= 0
				BEGIN
					SET @count_ncc_site3 = (SELECT COUNT(a.maNCC)
					FROM SITE3.QLHH.dbo.NHACUNGCAP as a WHERE a.maNCC = @maNCC)
					IF @count_ncc_site3 <= 0
						throw 51000, 'maNCC isnt exist', 1
				END
		END
	-- Check maSP
	IF (SELECT @@SERVERNAME) = 'PC3206'
	BEGIN
		IF (SELECT COUNT(a.maSP)
		FROM SITE1.QLHH.dbo.SANPHAM as a WHERE a.maSP = @maSP) <= 0
			throw 51000, 'maSP isnt exist', 1
		ELSE
			INSERT INTO SANXUAT([maNCC],[maSP],[SoLuong]) VALUES(@maNCC, @maSP, @Soluong)
	END
	IF (SELECT @@SERVERNAME) = 'PC3204'
	BEGIN
		IF (SELECT COUNT(a.maSP)
		FROM SITE2.QLHH.dbo.SANPHAM as a WHERE a.maSP = @maSP) <= 0
			throw 51000, 'maSP isnt exist', 1
		ELSE
			INSERT INTO SANXUAT([maNCC],[maSP],[SoLuong]) VALUES(@maNCC, @maSP, @Soluong)
	END
	IF (SELECT @@SERVERNAME) = 'PC3202'
	BEGIN -- SITE 1 hay 2 đều được ( Chọn site gần hơn )
		IF (SELECT COUNT(a.maSP)
		FROM SITE1.QLHH.dbo.SANPHAM as a WHERE a.maSP = @maSP) <= 0
			throw 51000, 'maSP isnt exist', 1
		ELSE
			INSERT INTO SANXUAT([maNCC],[maSP],[SoLuong]) VALUES(@maNCC, @maSP, @Soluong)
	END
END

