-- TRIGGER
CREATE Trigger trg_insert_SinhVien ON SV
FOR INSERT AS
BEGIN

	DECLARE @MaKhoa char(10)
	SET @MaKhoa = (SELECT MaKhoa FROM INSERTED)

	IF @MaKhoa != 1 AND @MaKhoa !=2 AND @MaKhoa != 3 
	BEGIN
		IF (SELECT Count(a.MaKhoa) FROM [SITE3].SinhVien.dbo.Khoa AS a INNER JOIN INSERTED AS b ON a.MaKhoa = b.MaKhoa) <= 0
		BEGIN
		RAISERROR ('MaKhoa doesnt exist', 15, 1);  
		ROLLBACK TRANSACTION
		RETURN
		END
	END

END

DROP TRIGGER trigger_Khoa

CREATE Trigger trg_delete_Khoa ON Khoa
FOR DELETE AS
BEGIN

	IF (SELECT Count(a.MaKhoa) FROM SV AS a INNER JOIN DELETED AS b ON a.MaKhoa = b.MaKhoa) > 0
	BEGIN
	RAISERROR ('Cannot DELETE', 15, 1);  
	ROLLBACK TRANSACTION
	END

END

DROP TRIGGER trg_delete_Khoa

-- PROCEDURE 1
CREATE PROCEDURE addKhoa
@MaKhoa char(10), @TenKhoa char(30)
AS
BEGIN

	IF @TenKhoa = 'Management'
		INSERT INTO Khoa VALUES (@MaKhoa, @TenKhoa)

	IF @TenKhoa = 'Math' OR @TenKhoa = 'English'
		INSERT INTO [SITE2].SinhVien.dbo.Khoa VALUES (@MaKhoa, @TenKhoa)

	IF @TenKhoa != 'Management' AND @TenKhoa != 'Math' AND @TenKhoa != 'English'
		INSERT INTO [SITE3].SinhVien.dbo.Khoa VALUES (@MaKhoa, @TenKhoa)

END

exec addKhoa @MaKhoa = '5', @TenKhoa = 'Chemistry'

DROP PROCEDURE addKhoa

--PROCEDURE 2
CREATE PROCEDURE addSinhVien
@MaSV char(6) , @HoTen char(30), @NgaySinh Date , @GioiTinh char(5) , @MaKhoa char(10), @DTB float
AS 
BEGIN 
	INSERT INTO SV VALUES (@MaSV, @HoTen, @NgaySinh, @GioiTinh, @MaKhoa)
	INSERT INTO SITE2.SinhVien.dbo.SV VALUES (@MaSV, @DTB)
END

DROP PROCEDURE addSinhVien

exec addSinhVien 'TEST' , 'TEST', '1111/11/11' , 'TEST' , 'TEST', 5.5

--FUNCTION
CREATE FUNCTION getDept (@TenKhoa char(30))
RETURNS TABLE
AS
BEGIN
	RETURN (
		CASE
			WHEN @TenKhoa = 'Management' THEN ( SELECT * FROM Khoa )
			WHEN @TenKhoa = 'Math' THEN ( SELECT * FROM [SITE2].SinhVien.dbo.Khoa )
			WHEN @TenKhoa = 'English' THEN ( SELECT * FROM [SITE2].SinhVien.dbo.Khoa )
			ELSE ( SELECT * FROM [SITE3].SinhVien.dbo.Khoa )
		END
	)
END

DROP FUNCTION getDept
---- TRIGGER KHOA
CREATE TRIGGER integrity_Khoa
ON Khoa
AFTER INSERT
AS
	DECLARE @id char(10);
	DECLARE @dept char(30);
	SET @id = (SELECT TOP 1 MaKhoa FROM inserted);
	SET @dept = (SELECT TOP 1 TenKhoa FROM inserted);
	
	-- Check key site 1
	IF (SELECT COUNT(a.MaKhoa)
	FROM SITE1.SinhVien.dbo.Khoa as a WHERE a.MaKhoa = @id) > 0
		THROW 51000, 'There is an existing entity with this primary key.', 1;
	-- Check key site 3
	IF (SELECT COUNT(a.MaKhoa)
	FROM SITE3.SinhVien.dbo.Khoa as a WHERE a.MaKhoa = @id) > 0
		THROW 51000, 'There is an existing entity with this primary key.', 1;
	
	-- SITE 1
	IF @dept = 'Management'
	BEGIN
		-- lock table
		SELECT *
		FROM SITE1.SinhVien.dbo.Khoa
		WITH (TABLOCK, HOLDLOCK)
		-- insert
		INSERT INTO SITE1.SinhVien.dbo.Khoa
		VALUES (@id, @dept)
		RETURN
	END
	-- SITE 2
	IF @dept = 'English' or @dept = 'Math'
	BEGIN
		-- SQL already validates if the key is existed in local table, so we only deal
		-- with new key, which SQL did it for us too.
		RETURN
	END
	-- SITE 3
	-- If not, we have to insert it here
	-- lock table
	SELECT *
	FROM SITE3.SinhVien.dbo.Khoa
	WITH (TABLOCK, HOLDLOCK)
	-- insert
	INSERT INTO SITE3.SinhVien.dbo.Khoa
	VALUES (@id, @dept)
	RETURN

DROP TRIGGER integrity_Khoa