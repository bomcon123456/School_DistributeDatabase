CREATE TRIGGER integrity_NCC_insert
ON NHACUNGCAP
INSTEAD OF INSERT
AS
	DECLARE @id char(10);
	DECLARE @name char(255);
	DECLARE @locate char(255);
	SET @id = (SELECT TOP 1 maNCC FROM inserted);
	SET @name = (SELECT TOP 1 tenNCC FROM inserted);
	SET @locate = (SELECT TOP 1 Khuvuc FROM inserted);
	
	-- Check key site 1
	IF (SELECT COUNT(a.maNCC)
	FROM SITE1.QLHH.dbo.NHACUNGCAP as a WHERE a.maNCC = @id) > 0
		THROW 51000, 'There is an existing entity with this primary key.', 1;
	-- Check key site 2
	IF (SELECT COUNT(a.maNCC)
	FROM QLHH.dbo.NHACUNGCAP as a WHERE a.maNCC = @id) > 0
		THROW 51000, 'There is an existing entity with this primary key.', 1;
	-- Check key site 3
	IF (SELECT COUNT(a.maNCC)
	FROM SITE3.QLHH.dbo.NHACUNGCAP as a WHERE a.maNCC = @id) > 0
		THROW 51000, 'There is an existing entity with this primary key.', 1;
	
	-- SITE 1
	IF @locate = 'Hanoi'
	BEGIN
		-- lock table
		SELECT *
		FROM SITE1.QLHH.dbo.NHACUNGCAP
		WITH (TABLOCK, HOLDLOCK)
		-- insert
		SET XACT_ABORT ON
		INSERT INTO SITE1.QLHH.dbo.NHACUNGCAP
		VALUES (@id, @name, @locate)
		RETURN
	END
	-- SITE 2
	IF @locate = 'TPHCM'
	BEGIN
		-- lock table
		SELECT *
		FROM QLHH.dbo.NHACUNGCAP
		WITH (TABLOCK, HOLDLOCK)
		-- insert
		SET XACT_ABORT ON
		INSERT INTO QLHH.dbo.NHACUNGCAP
		VALUES (@id, @name, @locate)
		RETURN
	END
	-- SITE 3
	-- If not, we have to insert it here
	-- lock table
	SELECT *
	FROM SITE3.QLHH.dbo.NHACUNGCAP
	WITH (TABLOCK, HOLDLOCK)
	-- insert
	SET XACT_ABORT ON
	INSERT INTO SITE3.QLHH.dbo.NHACUNGCAP
	VALUES (@id, @name, @locate)
	RETURN

DROP TRIGGER integrity_NCC_insert