CREATE TRIGGER integrity_NCC_delete
ON NHACUNGCAP
INSTEAD OF DELETE
AS
	DECLARE @id char(10);
	DECLARE @locate char(255);
	SET @id = (SELECT TOP 1 maNCC FROM deleted);
	SET @locate = (SELECT TOP 1 Khuvuc FROM deleted);
	
	---- Check key
	IF (SELECT COUNT(a.maNCC)
	FROM SANXUAT as a WHERE a.maNCC = @id) > 0
		THROW 51000, 'There is an existing entity with this primary key. Cant delete.', 1;
	-- SITE 1
	IF @locate = 'Hanoi'
	BEGIN
		-- lock table
		SELECT *
		FROM SITE1.QLHH.dbo.NHACUNGCAP
		WITH (TABLOCK, HOLDLOCK)
		-- delete
		DELETE FROM Site1.QLHH.[dbo].[NHACUNGCAP]
		WHERE maNCC = @id
		RETURN
	END
	-- SITE 2
	IF @locate = 'TPHCM'
	BEGIN
		-- lock table
		SELECT *
		FROM NHACUNGCAP
		WITH (TABLOCK, HOLDLOCK)
		-- delete
		DELETE FROM [NHACUNGCAP]
		WHERE maNCC = @id
		RETURN
	END
	-- SITE 3
	-- If not, we have to insert it here
	-- lock table
	SELECT *
	FROM SITE3.QLHH.dbo.NHACUNGCAP
	WITH (TABLOCK, HOLDLOCK)
	-- delete
	DELETE FROM Site3.QLHH.[dbo].[NHACUNGCAP]
	WHERE maNCC = @id
	RETURN

DROP TRIGGER integrity_NCC_delete